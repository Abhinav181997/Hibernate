package com.capgemini.payment.exceptions;

public class NameNotEnteredException extends Exception {

}
