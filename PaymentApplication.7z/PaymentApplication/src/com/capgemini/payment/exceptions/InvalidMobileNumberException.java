package com.capgemini.payment.exceptions;

public class InvalidMobileNumberException extends Exception {

}
