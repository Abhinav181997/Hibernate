package com.capgemini.payment.exceptions;

public class InsufficientAmountException extends Exception {

}
