package com.capgemini.payment.exceptions;

public class DuplicateMobileNumberException extends Exception {

}
